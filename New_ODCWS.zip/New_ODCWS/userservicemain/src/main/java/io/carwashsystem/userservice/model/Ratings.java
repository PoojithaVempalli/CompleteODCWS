package io.carwashsystem.userservice.model;

import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotEmpty;

import org.springframework.data.annotation.Id;

@Document(collection="Ratings")
public class Ratings {
	
	 int id;
	
	int rating;
	
	@NotEmpty(message = "Name must not be empty")
	static
	String washerName;
	static String comment;
	
	
	public int getid() {
		return id;
	}
	public void setid(int id) {
		this.id = id;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public static String getWasherName() {
		return washerName;
	}
	public void setWasherName(String washerName) {
		Ratings.washerName = washerName;
	}
	public static String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		Ratings.comment = comment;
	}
	
	@Override
	public String toString() {
		return "RatingDetails [id =" + id + ",rating=" + rating + ", washerName=" + washerName + ", comment=" + comment + "]";
	}
	
}
