package io.carwashsystem.userservice.model;

import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;

@Document(collection="WashPackages")
public class WashPacks {
	
	@Id
	int id;
	
	@NotNull
	@Size(min=2, message="Name should have atleast 2 characters")
	@NotEmpty(message = "Name must not be empty")
	String name;
	
	int cost;
	
	@NotEmpty(message = "Description must not be empty")
	String description;
	
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "WashPacks [id=" + id + ", name=" + name + ", cost=" + cost + ", description=" + description + "]";
	}
	
	
	
}
