package io.carwashsystem.adminservice.model;


import org.springframework.data.mongodb.core.mapping.Document;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;

@Document(collection="Admindata")
public class AdminDetails {
	
	@Id
	int id;
	
	@NotNull
	@Size(min=2, message="Name should have atleast 2 characters")
	@NotEmpty(message = "Name must not be empty")
	String name;
	
	@Size(min=5, message="Password should have atleast 5 characters")
	@NotEmpty(message = "Password must not be empty")
	String password;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "AdminDetails [id=" + id + ", name=" + name + ",password=" + password + "]";
	}
	
	
}
