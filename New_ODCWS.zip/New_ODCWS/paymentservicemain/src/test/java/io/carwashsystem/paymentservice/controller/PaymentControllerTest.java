package io.carwashsystem.paymentservice.controller;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import io.carwashsystem.paymentservice.model.*;
import io.carwashsystem.paymentservice.service.*;
import com.fasterxml.jackson.databind.ObjectMapper;
@ExtendWith(MockitoExtension.class)
public class PaymentControllerTest {
	

    @Autowired
    private MockMvc mockMvc;
    
    @Mock
    private PaymentService service;
    private PaymentDetails payment;
 
    @InjectMocks
    private PaymentController paymentController;
    
    @BeforeEach
    public void setUp(){
        payment = new PaymentDetails(2, 200, "True", "987");
        mockMvc= MockMvcBuilders.standaloneSetup(paymentController).build();
    }
    
    @Test
    public void doPayControllerTest() throws Exception {
       
        	when(service.doPay(any())).thenReturn(payment);
        mockMvc.perform(post("/payment/payments")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(payment)))
                .andExpect(status().isCreated());
        verify(service, times(1)).doPay(any());
    }
    
    public static String asJsonString(final Object obj){
        try{
        	String val = new ObjectMapper().writeValueAsString(obj);
        	System.out.println("val: " + val);
            return val;
        }catch(Exception e){
            throw new RuntimeException(e);
        }
    }
}
