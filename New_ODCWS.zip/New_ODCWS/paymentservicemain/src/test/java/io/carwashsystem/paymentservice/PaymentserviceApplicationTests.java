package io.carwashsystem.paymentservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import io.carwashsystem.paymentservice.model.PaymentDetails;
import io.carwashsystem.paymentservice.repo.PaymentRepository;
import io.carwashsystem.paymentservice.service.PaymentService;

@SpringBootTest
class PaymentserviceApplicationTests {

	@Mock
	PaymentRepository repository;
	
	@InjectMocks
	PaymentService paymentService;
	
	
	public List<PaymentDetails> payment;
	
	@Test
	public void test_doPay() {
		PaymentDetails payment = new PaymentDetails(1, 100, "True", "786");
		
		when(repository.save(payment)).thenReturn(payment);
		assertEquals(payment,paymentService.doPay(payment));
	}
}
